/***************************************************************************
**                                                                        **
**  Polyphone, a soundfont editor                                         **
**  Copyright (C) 2013-2016 Davy Triponney                                **
**                                                                        **
**  This program is free software: you can redistribute it and/or modify  **
**  it under the terms of the GNU General Public License as published by  **
**  the Free Software Foundation, either version 3 of the License, or     **
**  (at your option) any later version.                                   **
**                                                                        **
**  This program is distributed in the hope that it will be useful,       **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of        **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         **
**  GNU General Public License for more details.                          **
**                                                                        **
**  You should have received a copy of the GNU General Public License     **
**  along with this program.  If not, see http://www.gnu.org/licenses/.   **
**                                                                        **
****************************************************************************
**           Author: Davy Triponney                                       **
**  Website/Contact: http://polyphone-soundfonts.com                      **
**             Date: 01.01.2013                                           **
***************************************************************************/

#include "externalcommandrunner.h"
#include "sound.h"
#include <QProgressDialog>
#include <QApplication>
#include <QTemporaryFile>
#include <QDir>

ExternalCommandRunner::ExternalCommandRunner(Pile_sf2 *sf2, QWidget *parent) :
    QObject(parent),
    _sf2(sf2),
    _progress(NULL),
    _process(NULL)
{}

ExternalCommandRunner::~ExternalCommandRunner()
{
    delete _progress;
    if (_process != NULL)
        _process->kill();
}

void ExternalCommandRunner::run(QList<EltID> ids, QString command, bool stereo, bool replaceInfo)
{
    // Prepare the command
    _arguments = command.split(QRegExp(" +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"));
    if (_arguments.count() < 2 || _arguments.indexOf("{wav}") == -1 || ids.isEmpty())
    {
        this->deleteLater();
        return; // Shouldn't happen
    }
    _replaceInfo = replaceInfo;

    // IDs to process
    if (stereo)
        storeStereoIds(ids);
    else
        foreach (EltID id, ids)
            _remainingIds << (QList<EltID>() << id);

    // Program to call, argument to replace and ids to process
    _program = _arguments.takeFirst().replace("\"", "");
    _indexWav = _arguments.indexOf("{wav}");

    // Prepare and show the progress bar
    _progress = new QProgressDialog("", trUtf8("Annuler"), 0, _remainingIds.count(), (QWidget*)this->parent());
    _progress->setCancelButton(NULL);
    _progress->setWindowFlags(_progress->windowFlags() & ~Qt::WindowContextHelpButtonHint & ~Qt::WindowCloseButtonHint);
    _progress->setWindowModality(Qt::WindowModal);
    _progress->setFixedWidth(350);
    _progress->show();

    // Process the first sample
    processOne();
}

void ExternalCommandRunner::storeStereoIds(QList<EltID> ids)
{
    while (!ids.isEmpty())
    {
        QList<EltID> id;
        id << ids.takeFirst();
        SFSampleLink type = _sf2->get(id[0], champ_sfSampleType).sfLinkValue;

        if (type != monoSample && type != RomMonoSample)
        {
            // Find the other part of the sound
            EltID id2 = id[0];
            id2.indexElt = _sf2->get(id[0], champ_wSampleLink).wValue;
            if (_sf2->isValid(id2))
            {
                id << id2;
                ids.removeAll(id2);
            }
        }

        _remainingIds << id;
    }
}

void ExternalCommandRunner::processOne()
{
    // Take the first id in the remaining list
    QList<EltID> ids = _remainingIds.takeFirst();
    _id1 = ids[0];
    if (ids.count() == 2)
        _id2 = ids[1];
    else
        _id2.indexSf2 = -1;

    _progress->setValue(_progress->value() + 1);
    _progress->setLabelText(trUtf8("Traitement ") + _sf2->getQstr(_id1, champ_name) +
                            (ids.count() == 2 ? ", " + _sf2->getQstr(_id2, champ_name) : ""));
    QApplication::processEvents();

    // Export the sample in a temporary file
    QTemporaryFile * tempFile = new QTemporaryFile(QDir::tempPath() + "/" + QApplication::applicationName() + "-XXXXXX.wav");
    tempFile->open();
    _pathTempFile = tempFile->fileName();
    tempFile->close();
    if (ids.count() == 2)
        Sound::exporter(_pathTempFile, _sf2->getSon(_id1), _sf2->getSon(_id2));
    else
        Sound::exporter(_pathTempFile, _sf2->getSon(_id1));

#ifdef Q_OS_WIN
    _arguments[_indexWav] = _pathTempFile.replace('/', '\\');
#else
    _arguments[_indexWav] = _pathTempFile;
#endif

    // Definitely close the file
    tempFile->setAutoRemove(false);
    delete tempFile;

    // Start a new process
    _process = new QProcess(this);
    connect(_process, SIGNAL(stateChanged(QProcess::ProcessState)), this, SLOT(onProcessStateChanged(QProcess::ProcessState)));
    _process->start(_program, _arguments);
}

void ExternalCommandRunner::onProcessStateChanged(QProcess::ProcessState state)
{
    if (state != QProcess::NotRunning)
        return;

    // Delete the process that has just been used
    _process->deleteLater();
    _process = NULL;

    // Import the sample
    Sound sound(_pathTempFile, false);
    Valeur val;
    val.wValue = 0;
    sound.set(champ_wChannel, val);
    import(_id1, sound);
    if (_id2.indexSf2 != -1 && sound.get(champ_wChannels) == 2)
    {
        val.wValue = 1;
        sound.set(champ_wChannel, val);
        import(_id2, sound);
    }

    // Delete the temporary file
    QFile::remove(_pathTempFile);

    // Process the new sample if possible or quit
    if (_remainingIds.isEmpty() || _progress->wasCanceled())
    {
        emit(finished());
        this->deleteLater();
    }
    else
        processOne();
}

void ExternalCommandRunner::import(EltID id, Sound &sound)
{
    _sf2->set(id, champ_sampleDataFull24, sound.getData(24));

    Valeur val;
    val.dwValue = sound.get(champ_dwStart16);
    _sf2->set(id, champ_dwStart16, val);
    val.dwValue = sound.get(champ_dwStart24);
    _sf2->set(id, champ_dwStart24, val);
    val.dwValue = sound.get(champ_dwLength);
    _sf2->set(id, champ_dwLength, val);
    val.dwValue = sound.get(champ_dwSampleRate);
    _sf2->set(id, champ_dwSampleRate, val);

    // Sample configuration
    if (_replaceInfo)
    {
        // Loop
        val.dwValue = sound.get(champ_dwEndLoop);
        if (val.dwValue != 0)
        {
            _sf2->set(id, champ_dwEndLoop, val);
            val.dwValue = sound.get(champ_dwStartLoop);
            _sf2->set(id, champ_dwStartLoop, val);
        }

        // Original pitch and correction
        if (sound.get(champ_pitchDefined) == 1)
        {
            val.bValue = (quint8)sound.get(champ_byOriginalPitch);
            _sf2->set(id, champ_byOriginalPitch, val);
            val.cValue = (char)sound.get(champ_chPitchCorrection);
            _sf2->set(id, champ_chPitchCorrection, val);
        }
    }

    // Check that start loop and and loop are not out of range
    if (_sf2->get(id, champ_dwStartLoop).dwValue > sound.get(champ_dwLength) ||
        _sf2->get(id, champ_dwEndLoop).dwValue > sound.get(champ_dwLength))
    {
        val.dwValue = 0;
        _sf2->set(id, champ_dwStartLoop, val);
        _sf2->set(id, champ_dwEndLoop, val);
    }
}
