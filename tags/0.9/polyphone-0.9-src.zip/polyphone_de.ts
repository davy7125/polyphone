<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>ComboBox</name>
    <message>
        <location filename="pages/page.h" line="295"/>
        <source>Modulateur</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Config</name>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="29"/>
        <source>Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="43"/>
        <source>Général</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="49"/>
        <source>Gestion RAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="57"/>
        <source>Charger en mémoire lorsque nécessaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="62"/>
        <source>Tout charger en mémoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="70"/>
        <source>Sortie audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="80"/>
        <source>Entrée midi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="96"/>
        <source>Import fichiers wav</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="103"/>
        <source>ajuster à la boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="110"/>
        <source>enlever le blanc au départ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="118"/>
        <source>Synthétiseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="138"/>
        <source>Réverbération</source>
        <oldsource>Reverbération</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="174"/>
        <location filename="gui_divers/config.ui" line="332"/>
        <source>Niveau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="242"/>
        <source>Profondeur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="258"/>
        <source>Densité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="274"/>
        <source>Atténuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="299"/>
        <source>Chorus</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="374"/>
        <source>Fréquence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="390"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="476"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="435"/>
        <source>Gain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="489"/>
        <source>Graphique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="501"/>
        <source>Couleurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="528"/>
        <source>Arrière-plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="727"/>
        <source>Onde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="740"/>
        <source>Grille</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="759"/>
        <source>Début de boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="772"/>
        <source>Fin de boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="785"/>
        <source>Barre de lecture</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="822"/>
        <location filename="gui_divers/config.ui" line="1101"/>
        <source>Réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="848"/>
        <source>Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="874"/>
        <source>Actions disponibles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="1138"/>
        <source>Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.cpp" line="66"/>
        <source>Défaut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="152"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="153"/>
        <source>La modification sera prise en compte lors du prochain dÃ©marrage du logiciel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="498"/>
        <source>Couleur du fond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="508"/>
        <source>Couleur de l&apos;onde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="518"/>
        <source>Couleur de la grille</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.cpp" line="528"/>
        <source>Couleur du début de la boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="538"/>
        <source>Couleur de la fin de la boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="548"/>
        <source>Couleur du curseur de lecture</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.cpp" line="586"/>
        <location filename="gui_divers/config.cpp" line="602"/>
        <source>---- séparateur ----</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogCeleste</name>
    <message utf8="true">
        <location filename="tools/dialog_celeste.ui" line="29"/>
        <source>Accordage céleste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_celeste.ui" line="39"/>
        <source>Nombre de battements par secondes au do 4 (note 60)</source>
        <oldsource>Nombre de battements par secondes au do 3 (note 60)</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_celeste.ui" line="56"/>
        <source>Le signe définit le sens du désaccordage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_celeste.ui" line="79"/>
        <source>Division à l&apos;octave suivante</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogHelp</name>
    <message>
        <location filename="gui_divers/dialog_help.ui" line="20"/>
        <source>Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_help.cpp" line="34"/>
        <source>qrc:/aide/aide.html</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogList</name>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="53"/>
        <source>Liste des samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="58"/>
        <source>Liste des instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="63"/>
        <source>Liste des presets</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMagnetophone</name>
    <message utf8="true">
        <location filename="tools/dialog_magnetophone.ui" line="26"/>
        <source>Magnétophone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_magnetophone.cpp" line="96"/>
        <source>Sauvegarder un enregistrement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_magnetophone.cpp" line="97"/>
        <source>Fichier .wav (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_magnetophone.cpp" line="162"/>
        <location filename="tools/dialog_magnetophone.cpp" line="164"/>
        <source>enregistrement</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMixture</name>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="29"/>
        <source>Création mixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="47"/>
        <source>Nom de la mixture :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="57"/>
        <source>Création de son :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="65"/>
        <source>à chaque note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="70"/>
        <source>toutes les 3 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="75"/>
        <source>toutes les 6 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="83"/>
        <source>Bouclage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="100"/>
        <source>Divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="222"/>
        <source>Etendue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="268"/>
        <source>Rangs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="393"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="401"/>
        <source>octave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="406"/>
        <source>quinte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="411"/>
        <source>tierce</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="416"/>
        <source>septième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="421"/>
        <source>neuvième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="426"/>
        <source>onzième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="431"/>
        <source>treizième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="436"/>
        <source>quinzième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="441"/>
        <source>dix-septième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="446"/>
        <source>dix-neuvième</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="211"/>
        <source>sans nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="286"/>
        <source>32&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="287"/>
        <source>16&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="288"/>
        <source>8&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="289"/>
        <source>4&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="290"/>
        <source>2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="291"/>
        <source>1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="292"/>
        <source>1/2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="293"/>
        <source>1/4&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="294"/>
        <source>1/8&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="295"/>
        <source>1/16&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="301"/>
        <source>10&apos; 2/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="302"/>
        <source>5&apos; 1/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="303"/>
        <source>2&apos; 2/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="304"/>
        <source>1&apos; 1/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="305"/>
        <source>2/3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="306"/>
        <source>1/3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="307"/>
        <source>1/6&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="308"/>
        <source>1/12&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="314"/>
        <source>6&apos; 2/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="315"/>
        <source>3&apos; 1/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="316"/>
        <source>1&apos; 3/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="317"/>
        <source>4/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="318"/>
        <source>2/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="319"/>
        <source>1/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="320"/>
        <source>1/10&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="326"/>
        <source>4&apos; 4/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="327"/>
        <source>2&apos; 2/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="328"/>
        <source>1&apos; 1/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="329"/>
        <source>4/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="330"/>
        <source>2/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="331"/>
        <source>1/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="332"/>
        <source>1/14&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="338"/>
        <source>3&apos; 5/9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="339"/>
        <source>1&apos; 7/9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="340"/>
        <source>8/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="341"/>
        <source>4/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="342"/>
        <source>2/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="343"/>
        <source>1/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="349"/>
        <source>2&apos; 10/11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="350"/>
        <source>1&apos; 5/11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="351"/>
        <source>8/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="352"/>
        <source>4/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="353"/>
        <source>2/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="354"/>
        <source>1/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="360"/>
        <source>2&apos; 6/13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="361"/>
        <source>1&apos; 3/13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="362"/>
        <source>8/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="363"/>
        <source>4/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="364"/>
        <source>2/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="365"/>
        <source>1/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="371"/>
        <source>2&apos; 2/15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="372"/>
        <source>1&apos; 1/15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="373"/>
        <source>8/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="374"/>
        <source>4/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="375"/>
        <source>2/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="376"/>
        <source>1/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="382"/>
        <source>1&apos; 15/17</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="383"/>
        <source>16/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="384"/>
        <source>8/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="385"/>
        <source>4/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="386"/>
        <source>2/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="392"/>
        <source>1&apos; 13/19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="393"/>
        <source>16/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="394"/>
        <source>8/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="395"/>
        <source>4/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="396"/>
        <source>2/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogParamGlobal</name>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="26"/>
        <source>Paramétrage global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="80"/>
        <source>Motif</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.cpp" line="132"/>
        <source>Raideur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.cpp" line="137"/>
        <source>Répartition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.cpp" line="142"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="94"/>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="101"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="108"/>
        <source>Modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="115"/>
        <source>Paramètre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="147"/>
        <source>Manuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="152"/>
        <source>Linéaire ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="157"/>
        <source>Linéaire descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="162"/>
        <source>Exponentiel ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="167"/>
        <source>Exponentiel descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="172"/>
        <source>Aléatoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="223"/>
        <source>Ajout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="228"/>
        <source>Multiplication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="233"/>
        <source>Remplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="251"/>
        <source>Appliquer à d&apos;autres instruments...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.cpp" line="79"/>
        <source>Appliquer à d&apos;autres presets...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogRelease</name>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="26"/>
        <source>Élaboration release</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="111"/>
        <source>Désaccordage provoqué (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="58"/>
        <source>Durée release au do 2 (note 36)</source>
        <oldsource>Durée release au do 1 (note 36)</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="65"/>
        <source>Division à l&apos;octave suivante</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogRename</name>
    <message>
        <location filename="gui_divers/dialog_rename.ui" line="14"/>
        <source>Renommage de masse</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/dialog_rename.ui" line="27"/>
        <source>Nom des samples (20 caractères au total) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/dialog_rename.ui" line="37"/>
        <source>Écraser nom existant avec note de base en suffixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/dialog_rename.ui" line="47"/>
        <source>Écraser nom existant avec incrément en suffixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/dialog_rename.ui" line="54"/>
        <source>Préfixe au nom existant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_rename.ui" line="61"/>
        <source>Suffixe au nom existant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSelectItems</name>
    <message>
        <location filename="tools/dialog_selectitems.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_selectitems.ui" line="29"/>
        <source>Tout sélectionner</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_selectitems.ui" line="36"/>
        <source>Sélectionner
instrument courant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSifflements</name>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="17"/>
        <source>Diminuer sifflements</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_sifflements.ui" line="31"/>
        <source>Début de la coupure (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="38"/>
        <source>Fin de la coupure (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="45"/>
        <source>Raideur (0-10)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSpace</name>
    <message>
        <location filename="tools/dialog_space.ui" line="26"/>
        <source>Spatialisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="87"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Motif&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="94"/>
        <source>Nombre divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="101"/>
        <source>Etalement (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="108"/>
        <source>Occupation (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="115"/>
        <source>Offset (0-100)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="122"/>
        <source>Renversements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="151"/>
        <source>Ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="156"/>
        <source>Creux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="161"/>
        <source>Descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="166"/>
        <source>Pointe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogVisualizer</name>
    <message>
        <location filename="tools/dialog_visualizer.ui" line="17"/>
        <source>Visualiseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_visualizer.ui" line="89"/>
        <source>Visualisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_visualizer.ui" line="148"/>
        <source>Légende</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_visualizer.ui" line="169"/>
        <source>Valeur moyenne par note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_visualizer.ui" line="182"/>
        <source>Paramètres par défaut</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_visualizer.ui" line="195"/>
        <source>Paramètres définis</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_visualizer.ui" line="126"/>
        <source>échelle log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogWait</name>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="20"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="27"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphSpace</name>
    <message>
        <location filename="tools/dialog_space.cpp" line="316"/>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.cpp" line="325"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphVisualizer</name>
    <message>
        <location filename="tools/dialog_visualizer.cpp" line="504"/>
        <source>Impossible d&apos;afficher tous les points.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphiqueFourier</name>
    <message>
        <location filename="pages/page_smpl.cpp" line="1784"/>
        <source>note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1785"/>
        <source>correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1785"/>
        <source>estimation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="17"/>
        <source>Polyphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="117"/>
        <location filename="mainwindow.ui" line="144"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="191"/>
        <source>&amp;Fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="213"/>
        <source>&amp;Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="221"/>
        <source>&amp;Édition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="236"/>
        <source>&amp;Outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="243"/>
        <source>&amp;Sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="259"/>
        <source>&amp;Sf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="270"/>
        <source>&amp;Instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="286"/>
        <source>&amp;Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>A&amp;ffichage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="305"/>
        <source>Clavier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="324"/>
        <source>Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="372"/>
        <source>Arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="467"/>
        <source>Enroule l&apos;arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="493"/>
        <source>Déroule l&apos;arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="52"/>
        <source>Rechercher...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="532"/>
        <source>Efface la recherche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="559"/>
        <source>&amp;Ouvrir...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="562"/>
        <source>Ouvre un fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="565"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="574"/>
        <source>&amp;Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="577"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="586"/>
        <source>&amp;Manuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="589"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="598"/>
        <source>&amp;A propos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="610"/>
        <location filename="mainwindow.cpp" line="205"/>
        <location filename="mainwindow.cpp" line="316"/>
        <source>&amp;Enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="613"/>
        <source>Enregistre le fichier actuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="616"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="628"/>
        <source>Enregistrer &amp;sous...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="631"/>
        <source>Enregistre sous un autre fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="634"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="643"/>
        <source>&amp;Nouveau...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="646"/>
        <source>Crée un nouveau fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="649"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="661"/>
        <source>&amp;Annuler</source>
        <comment>1</comment>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="664"/>
        <source>Annule la dernière action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="667"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="679"/>
        <source>Ré&amp;tablir</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="682"/>
        <source>Refait la dernière action annulée</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="685"/>
        <source>Ctrl+Shift+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="694"/>
        <source>&amp;Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="697"/>
        <source>Ouvre les préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="708"/>
        <source>&amp;Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="711"/>
        <source>Afficher / masque la barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="723"/>
        <source>&amp;Fermer le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="726"/>
        <source>Ferme le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="729"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="741"/>
        <source>&amp;Copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="744"/>
        <source>Copie un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="747"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="762"/>
        <source>C&amp;oller</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="765"/>
        <source>Colle un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="768"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="783"/>
        <source>&amp;Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="786"/>
        <source>Supprime un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="789"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="804"/>
        <source>&amp;Enlever les éléments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="807"/>
        <source>Enleve les éléments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="819"/>
        <location filename="mainwindow.cpp" line="718"/>
        <location filename="mainwindow.cpp" line="730"/>
        <source>&amp;Renommer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="822"/>
        <source>Renomme un ou plusieurs élément(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="825"/>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="833"/>
        <source>fichier 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="836"/>
        <location filename="mainwindow.ui" line="850"/>
        <location filename="mainwindow.ui" line="864"/>
        <location filename="mainwindow.ui" line="878"/>
        <location filename="mainwindow.ui" line="892"/>
        <source>Ouvre un fichier récent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="847"/>
        <source>fichier 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="861"/>
        <source>fichier 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="875"/>
        <source>fichier 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="889"/>
        <source>fichier 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="906"/>
        <source>&amp;Section modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="909"/>
        <source>Affiche la section modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="921"/>
        <source>&amp;Importer ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="924"/>
        <source>Importe un fichier audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="936"/>
        <source>E&amp;xporter ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="939"/>
        <source>Exporte au format wav</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="951"/>
        <source>Nouvel instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="954"/>
        <source>Crée un nouvel instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="966"/>
        <source>Nouveau preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="969"/>
        <source>Crée un nouveau preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="981"/>
        <source>&amp;Enlever blanc au départ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="984"/>
        <source>Enleve le blanc au début d&apos;un sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="996"/>
        <source>&amp;Ajuster à la fin de boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="999"/>
        <source>Ajuste le sample à sa fin de boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1011"/>
        <source>&amp;Normaliser volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1014"/>
        <source>Normalise le volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1026"/>
        <source>&amp;Bouclage automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1029"/>
        <source>Boucle automatiquement le sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1041"/>
        <source>&amp;Filtre &quot;mur de brique&quot;...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1044"/>
        <source>Applique un filtre &quot;mur de brique&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1056"/>
        <source>&amp;Transposer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1059"/>
        <source>Transpose le sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1071"/>
        <source>&amp;Régler atténuation minimale...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1074"/>
        <source>Régle l&apos;atténuation minimale</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1086"/>
        <source>&amp;Accordage céleste...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1089"/>
        <source>Accorde les sons pour créer des battements</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1313"/>
        <source>Affiche le magnétophone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1325"/>
        <location filename="mainwindow.ui" line="1340"/>
        <source>&amp;Visualiseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1328"/>
        <location filename="mainwindow.ui" line="1343"/>
        <source>Visualise dans un graphique les paramètres utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1101"/>
        <location filename="mainwindow.ui" line="1355"/>
        <source>&amp;Spatialisation du son...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1104"/>
        <location filename="mainwindow.ui" line="1358"/>
        <source>Dispose les sons dans l&apos;espace</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1116"/>
        <source>&amp;Répartition automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1119"/>
        <source>Répartit automatiquement les sons sur le clavier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1131"/>
        <source>D&amp;uplication des divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1134"/>
        <location filename="mainwindow.ui" line="1256"/>
        <source>Duplique les divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1146"/>
        <location filename="mainwindow.ui" line="1283"/>
        <source>&amp;Paramétrage global...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1149"/>
        <location filename="mainwindow.ui" line="1286"/>
        <source>Paramètre toutes les divisions simultanément</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1161"/>
        <source>&amp;Réglage balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1164"/>
        <source>Règle la balance du sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1176"/>
        <source>&amp;Création mixture...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1179"/>
        <source>Crée une mixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1191"/>
        <source>&amp;Diminuer sifflements...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1194"/>
        <source>Diminue les sifflements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1205"/>
        <source>&amp;5 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1208"/>
        <source>affiche un clavier de 5 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1216"/>
        <source>&amp;6 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1219"/>
        <source>affiche un clavie de 6 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1227"/>
        <source>&amp;128 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1230"/>
        <source>affiche un clavier de 128 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1238"/>
        <source>&amp;Aucun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1241"/>
        <source>n&apos;affiche aucun clavier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1253"/>
        <source>&amp;Duplication des divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1268"/>
        <source>&amp;Élaboration release...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1271"/>
        <source>Crée automatiquement une release pour tous les sons liés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1298"/>
        <source>&amp;Association auto samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1301"/>
        <source>Associe automatiquement les samples G/D</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1310"/>
        <source>Magnétophone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="193"/>
        <source>&lt;b&gt;Les fichiers suivants ont Ã©tÃ© modifiÃ©s depuis leur dernier enregistrement :&lt;br/&gt; - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="199"/>
        <location filename="mainwindow.cpp" line="310"/>
        <source>&lt;b&gt;Voulez-vous enregistrer les modifications du fichier Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="199"/>
        <source>&amp;#160;Â» avant de quitter ?&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="202"/>
        <location filename="mainwindow.cpp" line="313"/>
        <source>Si vous n&apos;enregistrez pas, les modifications effectuÃ©es depuis la derniÃ¨re sauvegarde seront dÃ©finitivement perdues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="206"/>
        <location filename="mainwindow.cpp" line="317"/>
        <location filename="mainwindow.cpp" line="417"/>
        <source>&amp;Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="207"/>
        <source>&amp;Quitter sans enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="237"/>
        <source>Ouvrir une soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="239"/>
        <location filename="mainwindow.cpp" line="431"/>
        <location filename="mainwindow.cpp" line="435"/>
        <source>Fichier .sf2 (*.sf2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="264"/>
        <location filename="mainwindow.cpp" line="267"/>
        <location filename="mainwindow.cpp" line="270"/>
        <location filename="mainwindow.cpp" line="273"/>
        <location filename="mainwindow.cpp" line="276"/>
        <location filename="mainwindow.cpp" line="279"/>
        <location filename="mainwindow.cpp" line="451"/>
        <location filename="mainwindow.cpp" line="454"/>
        <location filename="mainwindow.cpp" line="457"/>
        <location filename="mainwindow.cpp" line="1655"/>
        <location filename="mainwindow.cpp" line="2139"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="267"/>
        <source>Le fichier est dÃ©jÃ  chargÃ©.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="270"/>
        <source>Impossible d&apos;ouvrir le fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="273"/>
        <source>Lecture impossible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="276"/>
        <source>Le fichier est corrompu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="279"/>
        <source>La somme de la taille des blocs ne donne pas la taille totale du fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="286"/>
        <source>Nom de la nouvelle soundfont :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="311"/>
        <source>&amp;#160;Â» avant de le fermer ?&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="318"/>
        <source>&amp;Fermer sans enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="383"/>
        <source>&lt;b&gt;Perte de rÃ©solution </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="383"/>
        <source> bits&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="385"/>
        <source>La qualitÃ© des samples sera abaissÃ©e suite Ã  cette opÃ©ration. Continuer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="388"/>
        <source>&amp;Oui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="389"/>
        <source>&amp;Non</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="405"/>
        <source>&lt;b&gt;Trop de paramètres dans les instruments et les presets.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="407"/>
        <source>&lt;b&gt;Trop de paramètres dans les instruments.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="409"/>
        <source>&lt;b&gt;Trop de paramètres dans les presets.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="411"/>
        <source>Certains synthétiseurs ne prennent pas en compte les paramètres au delà du 65536ème.
Diviser le fichier en plusieurs sf2 peut résoudre le problème.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="415"/>
        <source>&amp;Sauvegarder</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="416"/>
        <source>Sauvegarder, &amp;désactiver ce message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="431"/>
        <location filename="mainwindow.cpp" line="434"/>
        <source>Sauvegarder une soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="451"/>
        <source>Extension inconnue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="454"/>
        <source>Fichier dÃ©jÃ  ouvert, impossible de sauvegarder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="457"/>
        <source>Impossible d&apos;enregistrer le fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="488"/>
        <source>&lt;b&gt;Polyphone&lt;/b&gt; © 2013&lt;br/&gt;Version : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="489"/>
        <source>&lt;br/&gt;Auteur : Davy Triponney&lt;br/&gt;Site web : &lt;a href=&quot;http://www.polyphone.fr&quot;&gt;www.polyphone.fr&lt;/a&gt;&lt;br/&gt;Support : &lt;a href=&quot;mailto:info@polyphone.fr&quot;&gt;info@polyphone.fr&lt;/a&gt;</source>
        <oldsource>&lt;br/&gt;Auteur : Davy Triponney&lt;br/&gt;Support : &lt;a href=&quot;mailto:info@polyphone.fr&quot;&gt;info@polyphone.fr&lt;/a&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="725"/>
        <source>&amp;Renommer en masse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="933"/>
        <source>Nom du sample (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="934"/>
        <source>Nom de l&apos;instrument (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="935"/>
        <source>Nom du preset (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="936"/>
        <source>Nom du SF2 (max 255 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="937"/>
        <location filename="mainwindow.cpp" line="2498"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1253"/>
        <location filename="mainwindow.cpp" line="1853"/>
        <location filename="mainwindow.cpp" line="1859"/>
        <location filename="mainwindow.cpp" line="1868"/>
        <source>Le sample Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1254"/>
        <location filename="mainwindow.cpp" line="1869"/>
        <source>&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1259"/>
        <location filename="mainwindow.cpp" line="1372"/>
        <location filename="mainwindow.cpp" line="1592"/>
        <location filename="mainwindow.cpp" line="1883"/>
        <source>&amp;Remplacer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1260"/>
        <location filename="mainwindow.cpp" line="1373"/>
        <location filename="mainwindow.cpp" line="1593"/>
        <location filename="mainwindow.cpp" line="1884"/>
        <source>R&amp;emplacer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1261"/>
        <location filename="mainwindow.cpp" line="1374"/>
        <location filename="mainwindow.cpp" line="1594"/>
        <location filename="mainwindow.cpp" line="1885"/>
        <source>&amp;Dupliquer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1262"/>
        <location filename="mainwindow.cpp" line="1375"/>
        <location filename="mainwindow.cpp" line="1595"/>
        <location filename="mainwindow.cpp" line="1886"/>
        <source>D&amp;upliquer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1263"/>
        <location filename="mainwindow.cpp" line="1376"/>
        <location filename="mainwindow.cpp" line="1596"/>
        <location filename="mainwindow.cpp" line="1887"/>
        <source>&amp;Ignorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1264"/>
        <location filename="mainwindow.cpp" line="1377"/>
        <location filename="mainwindow.cpp" line="1597"/>
        <location filename="mainwindow.cpp" line="1888"/>
        <source>I&amp;gnorer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1366"/>
        <source>L&apos;instrument Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1367"/>
        <location filename="mainwindow.cpp" line="1587"/>
        <source>&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Souhaitez-vous le remplacer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1586"/>
        <source>Le preset Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1655"/>
        <location filename="mainwindow.cpp" line="2139"/>
        <source>Aucun preset n&apos;est disponible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1817"/>
        <source>Importer un fichier audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1818"/>
        <source>Fichier .wav (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1854"/>
        <source>L&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1860"/>
        <source>R&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="1999"/>
        <source>Choisir un répertoire de destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2113"/>
        <source>Nom du nouvel instrument :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2149"/>
        <source>Nom du nouveau preset :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2482"/>
        <source>%d sample et </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2483"/>
        <source>%d samples et </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2485"/>
        <source>%d instrument ont Ã©tÃ© supprimÃ©s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2486"/>
        <source>%d instruments ont Ã©tÃ© supprimÃ©s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2499"/>
        <source>AttÃ©nuation minimale (dB) :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page</name>
    <message>
        <location filename="pages/page.cpp" line="104"/>
        <source>, valeur absolue</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="260"/>
        <location filename="pages/page.cpp" line="292"/>
        <location filename="pages/page.cpp" line="572"/>
        <source>Offset début sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="268"/>
        <location filename="pages/page.cpp" line="356"/>
        <source>Offset fin sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="276"/>
        <source>Offset début boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="284"/>
        <location filename="pages/page.cpp" line="604"/>
        <source>Offset fin boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="300"/>
        <location filename="pages/page.cpp" line="301"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="308"/>
        <location filename="pages/page.cpp" line="309"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="316"/>
        <location filename="pages/page.cpp" line="317"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="324"/>
        <source>Filtre, fréquence (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="325"/>
        <source>Filtre, fréquence (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="332"/>
        <location filename="pages/page.cpp" line="333"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="340"/>
        <location filename="pages/page.cpp" line="341"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="348"/>
        <location filename="pages/page.cpp" line="349"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="364"/>
        <location filename="pages/page.cpp" line="365"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="372"/>
        <location filename="pages/page.cpp" line="373"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="380"/>
        <location filename="pages/page.cpp" line="381"/>
        <source>Réverbération (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="388"/>
        <source>Balance [-50;50]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="389"/>
        <source>Balance [-100;100]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="396"/>
        <source>Mod LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="397"/>
        <source>Mod LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="404"/>
        <source>Mod LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="405"/>
        <source>Mod LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="412"/>
        <source>Vib LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="413"/>
        <source>Vib LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="420"/>
        <source>Vib LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="421"/>
        <source>Vib LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="428"/>
        <source>Mod env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="429"/>
        <source>Mod env delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="436"/>
        <source>Mod env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="437"/>
        <source>Mod env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="444"/>
        <source>Mod env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="445"/>
        <source>Mod env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="452"/>
        <source>Mod env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="453"/>
        <source>Mod env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="460"/>
        <location filename="pages/page.cpp" line="461"/>
        <source>Mod env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="468"/>
        <source>Mod env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="469"/>
        <source>Mod env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="476"/>
        <location filename="pages/page.cpp" line="477"/>
        <source>Note → Mod env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="484"/>
        <location filename="pages/page.cpp" line="485"/>
        <source>Note → Mod env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="492"/>
        <location filename="pages/page.cpp" line="516"/>
        <source>Vol env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="493"/>
        <location filename="pages/page.cpp" line="517"/>
        <source>Vol env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="500"/>
        <source>Vol env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="501"/>
        <source>Vol env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="508"/>
        <source>Vol env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="509"/>
        <source>Vol env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="524"/>
        <location filename="pages/page.cpp" line="525"/>
        <source>Vol env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="532"/>
        <source>Vol env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="533"/>
        <source>Vol env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="540"/>
        <location filename="pages/page.cpp" line="541"/>
        <source>Note → Vol env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="548"/>
        <location filename="pages/page.cpp" line="549"/>
        <source>Note → Vol env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="556"/>
        <location filename="pages/page.cpp" line="557"/>
        <source>Étendue note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="564"/>
        <location filename="pages/page.cpp" line="565"/>
        <source>Étendue vélocité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="580"/>
        <source>Note fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="588"/>
        <source>Vélocité fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="596"/>
        <location filename="pages/page.cpp" line="597"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="612"/>
        <location filename="pages/page.cpp" line="613"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="620"/>
        <location filename="pages/page.cpp" line="621"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="628"/>
        <source>Lecture en boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="636"/>
        <location filename="pages/page.cpp" line="637"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="644"/>
        <source>Classe exclusive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="652"/>
        <source>Note de base</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageTable</name>
    <message>
        <location filename="pages/page.cpp" line="829"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="1099"/>
        <location filename="pages/page.cpp" line="1121"/>
        <location filename="pages/page.cpp" line="2085"/>
        <location filename="pages/page.cpp" line="2154"/>
        <source>Modulateur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="1103"/>
        <source>Lien (invalide)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2299"/>
        <source>Action impossible : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2309"/>
        <location filename="pages/page.cpp" line="2318"/>
        <location filename="pages/page.cpp" line="2785"/>
        <location filename="pages/page.cpp" line="2787"/>
        <location filename="pages/page.cpp" line="2794"/>
        <location filename="pages/page.cpp" line="2796"/>
        <location filename="pages/page.cpp" line="2868"/>
        <location filename="pages/page.cpp" line="2877"/>
        <location filename="pages/page.cpp" line="2981"/>
        <location filename="pages/page.cpp" line="2990"/>
        <location filename="pages/page.cpp" line="3204"/>
        <location filename="pages/page.cpp" line="3206"/>
        <location filename="pages/page.cpp" line="3212"/>
        <location filename="pages/page.cpp" line="3214"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2310"/>
        <source>les offsets ne peuvent être modulés dans un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2319"/>
        <source>&quot; ne peut être modulé dans un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2785"/>
        <location filename="pages/page.cpp" line="2868"/>
        <location filename="pages/page.cpp" line="2981"/>
        <location filename="pages/page.cpp" line="3204"/>
        <source>L&apos;instrument doit contenir des sons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2787"/>
        <location filename="pages/page.cpp" line="2877"/>
        <location filename="pages/page.cpp" line="2990"/>
        <location filename="pages/page.cpp" line="3206"/>
        <source>Le preset doit contenir des instruments.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2794"/>
        <location filename="pages/page.cpp" line="3212"/>
        <source>Aucune étendue de notes spécifiée pour l&apos;instrument.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2796"/>
        <location filename="pages/page.cpp" line="3214"/>
        <source>Aucune étendue de notes spécifiée pour le preset.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Inst</name>
    <message>
        <location filename="pages/page_inst.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="80"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="141"/>
        <location filename="pages/page_inst.ui" line="624"/>
        <source>typeElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="146"/>
        <location filename="pages/page_inst.ui" line="629"/>
        <source>indexSf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="151"/>
        <location filename="pages/page_inst.ui" line="634"/>
        <source>indexElt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="156"/>
        <location filename="pages/page_inst.ui" line="639"/>
        <source>indexElt2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="161"/>
        <source>Etendue note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="166"/>
        <source>Etendue vélocité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="171"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="176"/>
        <source>Balance [-50;50]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="181"/>
        <source>Lecture en boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="186"/>
        <source>Note de base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="191"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="196"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="201"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="206"/>
        <source>Filtre, fréquence (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="217"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="222"/>
        <source>Vol env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="227"/>
        <source>Vol env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="232"/>
        <source>Vol env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="237"/>
        <source>Vol env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="242"/>
        <source>Vol env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="247"/>
        <source>Vol env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="252"/>
        <source>Note → Vol env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="257"/>
        <source>Note → Vol env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="262"/>
        <source>Mod env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="267"/>
        <source>Mod env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="272"/>
        <source>Mod env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="277"/>
        <source>Mod env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="282"/>
        <source>Mod env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="287"/>
        <source>Mod env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="292"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="297"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="302"/>
        <source>Note → Mod env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="307"/>
        <source>Note → Mod env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="312"/>
        <source>Mod LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="317"/>
        <source>Mod LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="322"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="327"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="332"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="337"/>
        <source>Vib LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="342"/>
        <source>Vib LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="347"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="352"/>
        <source>Classe exclusive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="357"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="362"/>
        <source>Réverbération (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="367"/>
        <source>Note fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="372"/>
        <source>Vélocité fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="377"/>
        <source>Offset début sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="382"/>
        <source>Offset fin sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="387"/>
        <source>Offset début boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="392"/>
        <source>Offset fin boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="397"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="462"/>
        <source>Modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="525"/>
        <source>copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="538"/>
        <source>coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="644"/>
        <source>indexMod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="649"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="660"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="671"/>
        <source>Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="682"/>
        <location filename="pages/page_inst.ui" line="882"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="714"/>
        <source>Source / Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="924"/>
        <source>Valeur abs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="117"/>
        <source>&lt;b&gt;Instrument liÃ© Ã  aucun preset.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="119"/>
        <source>&lt;b&gt;Instrument liÃ© au preset : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="121"/>
        <source>&lt;b&gt;Instrument liÃ© aux presets : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="132"/>
        <location filename="pages/page_inst.cpp" line="227"/>
        <location filename="pages/page_inst.cpp" line="311"/>
        <location filename="pages/page_inst.cpp" line="524"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="132"/>
        <location filename="pages/page_inst.cpp" line="227"/>
        <location filename="pages/page_inst.cpp" line="311"/>
        <location filename="pages/page_inst.cpp" line="524"/>
        <source>L&apos;instrument doit contenir des sons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.cpp" line="332"/>
        <source>Création </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="333"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="348"/>
        <source>sans nom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Prst</name>
    <message>
        <location filename="pages/page_prst.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="64"/>
        <source>Banque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="114"/>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="203"/>
        <location filename="pages/page_prst.ui" line="641"/>
        <source>typeElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="208"/>
        <location filename="pages/page_prst.ui" line="646"/>
        <source>indexSf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="213"/>
        <location filename="pages/page_prst.ui" line="651"/>
        <source>indexElt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="218"/>
        <location filename="pages/page_prst.ui" line="656"/>
        <source>indexElt2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="223"/>
        <source>Etendue note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="228"/>
        <source>Etendue vélocité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="233"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="238"/>
        <source>Balance [-100;100]</source>
        <oldsource>Balance [-50;50]</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="243"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="248"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="253"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="258"/>
        <source>Filtre, fréquence (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="269"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="274"/>
        <source>Vol env delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="279"/>
        <source>Vol env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="284"/>
        <source>Vol env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="289"/>
        <source>Vol env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="294"/>
        <source>Vol env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="299"/>
        <source>Vol env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="304"/>
        <source>Note → Vol env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="309"/>
        <source>Note → Vol env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="314"/>
        <source>Mod env delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="319"/>
        <source>Mod env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="324"/>
        <source>Mod env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="329"/>
        <source>Mod env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="334"/>
        <source>Mod env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="339"/>
        <source>Mod env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="344"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="349"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="354"/>
        <source>Note → Mod env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="359"/>
        <source>Note → Mod env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="364"/>
        <source>Mod LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="369"/>
        <source>Mod LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="374"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="379"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="384"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="389"/>
        <source>Vib LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="394"/>
        <source>Vib LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="399"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="404"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="409"/>
        <source>Réverbération (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="414"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="479"/>
        <source>Modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="542"/>
        <source>copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="555"/>
        <source>coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="661"/>
        <source>indexMod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="666"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="677"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="688"/>
        <source>Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="699"/>
        <location filename="pages/page_prst.ui" line="899"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="731"/>
        <source>Source / Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="941"/>
        <source>Valeur abs.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Sf2</name>
    <message>
        <location filename="pages/page_sf2.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="42"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="49"/>
        <source>Auteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="56"/>
        <source>Copyright</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="63"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="94"/>
        <source>Date courante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="101"/>
        <source>Produit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="117"/>
        <source>Samples 24 bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="124"/>
        <source>Commentaires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="144"/>
        <source>Nom du fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="151"/>
        <source>Version Soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="158"/>
        <source>Sound engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="165"/>
        <source>Nom et version ROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="172"/>
        <source>Logiciel(s) d&apos;édition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="186"/>
        <location filename="pages/page_sf2.ui" line="199"/>
        <location filename="pages/page_sf2.ui" line="206"/>
        <location filename="pages/page_sf2.ui" line="213"/>
        <location filename="pages/page_sf2.ui" line="220"/>
        <location filename="pages/page_sf2.ui" line="298"/>
        <location filename="pages/page_sf2.ui" line="305"/>
        <location filename="pages/page_sf2.ui" line="312"/>
        <location filename="pages/page_sf2.ui" line="319"/>
        <location filename="pages/page_sf2.ui" line="326"/>
        <location filename="pages/page_sf2.ui" line="333"/>
        <location filename="pages/page_sf2.ui" line="340"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="245"/>
        <source>Nombre de samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="252"/>
        <source>Nombre de samples non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="259"/>
        <source>Nombre d&apos;instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="266"/>
        <source>Nombre d&apos;instruments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="273"/>
        <source>Nombre de presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="280"/>
        <source>Nombre de paramètres renseignés pour les instruments</source>
        <oldsource>Nombre de paramètres renseignés pour instruments</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="287"/>
        <source>Nombre de paramètres renseignés pour les presets</source>
        <oldsource>Nombre de paramètres renseignés pour presets</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.cpp" line="229"/>
        <location filename="pages/page_sf2.cpp" line="239"/>
        <source> (≤ 65536)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Smpl</name>
    <message>
        <location filename="pages/page_smpl.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="77"/>
        <location filename="pages/page_smpl.ui" line="984"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="176"/>
        <source>&lt;b&gt;Fréquences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="195"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Informations&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="208"/>
        <source>&lt;b&gt;Egaliseur&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="260"/>
        <source>32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="299"/>
        <source>64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="341"/>
        <source>125</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="380"/>
        <source>250</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="419"/>
        <source>500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="458"/>
        <source>1k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="497"/>
        <source>2k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="536"/>
        <source>4k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="575"/>
        <source>8k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="614"/>
        <source>16k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="669"/>
        <source> +15dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="692"/>
        <source>Réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="705"/>
        <source>Appliquer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="725"/>
        <source> -15dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="808"/>
        <source>Lecture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="840"/>
        <source>en boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="875"/>
        <source>stéréo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="882"/>
        <source>sinus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="916"/>
        <source>Taille</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="923"/>
        <source>Boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="930"/>
        <source>Note de base</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="937"/>
        <source>Correction (centième)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="944"/>
        <source>Echantillonnage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="951"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="958"/>
        <source>Lien</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1081"/>
        <source>192000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1086"/>
        <source>96000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1091"/>
        <source>48000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1096"/>
        <source>44100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1101"/>
        <source>32000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1106"/>
        <source>22050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1111"/>
        <source>11025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="117"/>
        <location filename="pages/page_smpl.cpp" line="360"/>
        <location filename="pages/page_smpl.cpp" line="490"/>
        <location filename="pages/page_smpl.cpp" line="506"/>
        <source>mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="127"/>
        <location filename="pages/page_smpl.cpp" line="491"/>
        <source>droit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="128"/>
        <location filename="pages/page_smpl.cpp" line="492"/>
        <source>gauche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="129"/>
        <location filename="pages/page_smpl.cpp" line="493"/>
        <source>lien</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="183"/>
        <source>&lt;b&gt;Sample liÃ© Ã  aucun instrument.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="185"/>
        <source>&lt;b&gt;Sample liÃ© Ã  l&apos;instrument : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="187"/>
        <source>&lt;b&gt;Sample liÃ© aux instruments : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="588"/>
        <location filename="pages/page_smpl.cpp" line="643"/>
        <location filename="pages/page_smpl.cpp" line="719"/>
        <location filename="pages/page_smpl.cpp" line="789"/>
        <location filename="pages/page_smpl.cpp" line="866"/>
        <location filename="pages/page_smpl.cpp" line="927"/>
        <location filename="pages/page_smpl.cpp" line="1033"/>
        <location filename="pages/page_smpl.cpp" line="1097"/>
        <source>Traitement </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="589"/>
        <location filename="pages/page_smpl.cpp" line="644"/>
        <location filename="pages/page_smpl.cpp" line="720"/>
        <location filename="pages/page_smpl.cpp" line="790"/>
        <location filename="pages/page_smpl.cpp" line="867"/>
        <location filename="pages/page_smpl.cpp" line="928"/>
        <location filename="pages/page_smpl.cpp" line="1034"/>
        <location filename="pages/page_smpl.cpp" line="1098"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="845"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="846"/>
        <source>FrÃ©quence de coupure :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1074"/>
        <source>Transposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1075"/>
        <source>Ãcart en demi-tons :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PianoScene</name>
    <message>
        <location filename="clavier/pianoscene.cpp" line="275"/>
        <location filename="clavier/pianoscene.cpp" line="278"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="275"/>
        <source>C♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="275"/>
        <location filename="clavier/pianoscene.cpp" line="278"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="275"/>
        <source>D♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="275"/>
        <location filename="clavier/pianoscene.cpp" line="278"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="276"/>
        <location filename="clavier/pianoscene.cpp" line="279"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="276"/>
        <source>F♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="276"/>
        <location filename="clavier/pianoscene.cpp" line="279"/>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="276"/>
        <source>G♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="277"/>
        <location filename="clavier/pianoscene.cpp" line="280"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="277"/>
        <source>A♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="277"/>
        <location filename="clavier/pianoscene.cpp" line="280"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="278"/>
        <source>D♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="278"/>
        <source>E♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="279"/>
        <source>G♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="279"/>
        <source>A♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="280"/>
        <source>B♭</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pile_sf2</name>
    <message>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="746"/>
        <source>sans titre</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="122"/>
        <location filename="sf2_core/pile_sf2.cpp" line="217"/>
        <location filename="sf2_core/pile_sf2.cpp" line="401"/>
        <location filename="sf2_core/pile_sf2.cpp" line="414"/>
        <location filename="sf2_core/pile_sf2.cpp" line="485"/>
        <location filename="sf2_core/pile_sf2.cpp" line="539"/>
        <location filename="sf2_core/pile_sf2.cpp" line="885"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1182"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1275"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1359"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1605"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1612"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1856"/>
        <location filename="sf2_core/pile_sf2.cpp" line="2051"/>
        <location filename="sf2_core/pile_sf2.cpp" line="2111"/>
        <location filename="sf2_core/pile_sf2.cpp" line="2426"/>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="284"/>
        <location filename="sf2_core/sf2_types.cpp" line="37"/>
        <location filename="sf2_core/sound.cpp" line="102"/>
        <location filename="sf2_core/sound.cpp" line="154"/>
        <location filename="sf2_core/sound.cpp" line="227"/>
        <location filename="sf2_core/sound.cpp" line="302"/>
        <location filename="sf2_core/sound.cpp" line="311"/>
        <location filename="sf2_core/sound.cpp" line="373"/>
        <location filename="sf2_core/sound.cpp" line="615"/>
        <location filename="sf2_core/sound.cpp" line="629"/>
        <location filename="sf2_core/sound.cpp" line="636"/>
        <location filename="sf2_core/sound.cpp" line="642"/>
        <location filename="sf2_core/sound.cpp" line="656"/>
        <location filename="sf2_core/sound.cpp" line="664"/>
        <location filename="sf2_core/sound.cpp" line="1156"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="122"/>
        <source>Dans fonction Pile_sf2::isSet, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="217"/>
        <source>Dans fonction Pile_sf2::get, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="401"/>
        <source>Dans fonction Pile_sf2::getSon, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="414"/>
        <source>Dans fonction Pile_sf2::getQstr, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="485"/>
        <source>Dans fonction Pile_sf2::getData, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="539"/>
        <source>Dans fonction Pile_sf2::count, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="885"/>
        <source>Dans fonction Pile_sf2::add, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="931"/>
        <source>Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="939"/>
        <source>Instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="946"/>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1182"/>
        <source>Dans fonction Pile_sf2::remove, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1276"/>
        <source>Impossible de supprimer un sample s&apos;il est utilisÃ© par un instrument.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1360"/>
        <source>Impossible de supprimer un instrument s&apos;il est utilisÃ© par un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1605"/>
        <source>Set hidden ne passe pas par la fonction set !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1612"/>
        <source>Dans fonction Pile_sf2::set (valeur), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1856"/>
        <source>Dans fonction Pile_sf2::set (QString), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="2051"/>
        <source>Dans fonction Pile_sf2::set (data), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="2111"/>
        <source>Dans fonction Pile_sf2::reset, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="2426"/>
        <source>Dans fonction Pile_sf2::display, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="285"/>
        <source>Fichier corrompu : utilisation des samples en qualitÃ© 16 bits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sf2_types.cpp" line="37"/>
        <source>Lecture impossible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="102"/>
        <location filename="sf2_core/sound.cpp" line="154"/>
        <location filename="sf2_core/sound.cpp" line="227"/>
        <location filename="sf2_core/sound.cpp" line="302"/>
        <source>Fichier non pris en charge.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="311"/>
        <source>Erreur dans Sound::getData.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="374"/>
        <source>Dans setData : opÃ©ration non autorisÃ©e.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="616"/>
        <source>Impossible d&apos;ouvrir le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="629"/>
        <location filename="sf2_core/sound.cpp" line="636"/>
        <location filename="sf2_core/sound.cpp" line="642"/>
        <location filename="sf2_core/sound.cpp" line="656"/>
        <source>Le fichier est corrompu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="665"/>
        <source>RÃ©solution insuffisante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="1157"/>
        <source>Mauvais paramÃ¨tres dans bandFilter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tree</name>
    <message>
        <location filename="sf2_core/tree.cpp" line="52"/>
        <source>Nouveau sample...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="55"/>
        <source>Nouvel instrument...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="58"/>
        <source>Nouveau preset...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="66"/>
        <source>Remplacer par...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="sf2_core/tree.cpp" line="63"/>
        <source>Associer à...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="71"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="72"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="77"/>
        <source>Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="83"/>
        <source>Fermer le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="208"/>
        <location filename="sf2_core/tree.cpp" line="220"/>
        <location filename="sf2_core/tree.cpp" line="234"/>
        <source>&amp;Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="84"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="215"/>
        <source>&amp;Renommer en masse...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
