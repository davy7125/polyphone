<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>ComboBox</name>
    <message>
        <location filename="pages/page.h" line="287"/>
        <source>Modulateur</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Config</name>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="29"/>
        <source>Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="43"/>
        <source>Général</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="49"/>
        <source>Gestion RAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="57"/>
        <source>Charger en mémoire lorsque nécessaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="62"/>
        <source>Tout charger en mémoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="70"/>
        <source>Sortie audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="80"/>
        <source>Entrée midi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="96"/>
        <source>Import fichiers wav</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="103"/>
        <source>ajuster à la boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="110"/>
        <source>enlever le blanc au départ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="118"/>
        <source>Synthétiseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="138"/>
        <source>Réverbération</source>
        <oldsource>Reverbération</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="174"/>
        <location filename="gui_divers/config.ui" line="332"/>
        <source>Niveau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="242"/>
        <source>Profondeur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="258"/>
        <source>Densité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="274"/>
        <source>Atténuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="299"/>
        <source>Chorus</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.ui" line="374"/>
        <source>Fréquence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="390"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="476"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="435"/>
        <source>Gain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.ui" line="507"/>
        <source>Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="gui_divers/config.cpp" line="50"/>
        <source>Défaut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="132"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/config.cpp" line="133"/>
        <source>La modification sera prise en compte lors du prochain dÃ©marrage du logiciel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogHelp</name>
    <message>
        <location filename="gui_divers/dialog_help.ui" line="26"/>
        <source>Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_help.cpp" line="33"/>
        <source>qrc:/aide/aide.html</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogList</name>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="53"/>
        <source>Liste des samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="58"/>
        <source>Liste des instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_list.cpp" line="63"/>
        <source>Liste des presets</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMixture</name>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="29"/>
        <source>Création mixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="47"/>
        <source>Nom de la mixture :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="57"/>
        <source>Création de son :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="65"/>
        <source>à chaque note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="70"/>
        <source>toutes les 3 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="75"/>
        <source>toutes les 6 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="83"/>
        <source>Bouclage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="100"/>
        <source>Divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="222"/>
        <source>Etendue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="268"/>
        <source>Rangs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="393"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="401"/>
        <source>octave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="406"/>
        <source>quinte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.ui" line="411"/>
        <source>tierce</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="416"/>
        <source>septième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="421"/>
        <source>neuvième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="426"/>
        <source>onzième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="431"/>
        <source>treizième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="436"/>
        <source>quinzième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="441"/>
        <source>dix-septième</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_mixture.ui" line="446"/>
        <source>dix-neuvième</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="186"/>
        <source>sans nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="261"/>
        <source>32&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="262"/>
        <source>16&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="263"/>
        <source>8&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="264"/>
        <source>4&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="265"/>
        <source>2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="266"/>
        <source>1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="267"/>
        <source>1/2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="268"/>
        <source>1/4&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="269"/>
        <source>1/8&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="270"/>
        <source>1/16&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="276"/>
        <source>10&apos; 2/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="277"/>
        <source>5&apos; 1/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="278"/>
        <source>2&apos; 2/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="279"/>
        <source>1&apos; 1/3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="280"/>
        <source>2/3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="281"/>
        <source>1/3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="282"/>
        <source>1/6&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="283"/>
        <source>1/12&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="289"/>
        <source>6&apos; 2/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="290"/>
        <source>3&apos; 1/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="291"/>
        <source>1&apos; 3/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="292"/>
        <source>4/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="293"/>
        <source>2/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="294"/>
        <source>1/5&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="295"/>
        <source>1/10&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="301"/>
        <source>4&apos; 4/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="302"/>
        <source>2&apos; 2/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="303"/>
        <source>1&apos; 1/7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="304"/>
        <source>4/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="305"/>
        <source>2/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="306"/>
        <source>1/7&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="307"/>
        <source>1/14&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="313"/>
        <source>3&apos; 5/9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="314"/>
        <source>1&apos; 7/9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="315"/>
        <source>8/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="316"/>
        <source>4/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="317"/>
        <source>2/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="318"/>
        <source>1/9&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="324"/>
        <source>2&apos; 10/11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="325"/>
        <source>1&apos; 5/11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="326"/>
        <source>8/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="327"/>
        <source>4/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="328"/>
        <source>2/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="329"/>
        <source>1/11&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="335"/>
        <source>2&apos; 6/13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="336"/>
        <source>1&apos; 3/13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="337"/>
        <source>8/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="338"/>
        <source>4/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="339"/>
        <source>2/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="340"/>
        <source>1/13&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="346"/>
        <source>2&apos; 2/15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="347"/>
        <source>1&apos; 1/15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="348"/>
        <source>8/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="349"/>
        <source>4/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="350"/>
        <source>2/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="351"/>
        <source>1/15&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="357"/>
        <source>1&apos; 15/17</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="358"/>
        <source>16/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="359"/>
        <source>8/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="360"/>
        <source>4/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="361"/>
        <source>2/17&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="367"/>
        <source>1&apos; 13/19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="368"/>
        <source>16/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="369"/>
        <source>8/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="370"/>
        <source>4/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_mixture.cpp" line="371"/>
        <source>2/19&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogParamGlobal</name>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="26"/>
        <source>Paramétrage global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="80"/>
        <source>Motif</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.cpp" line="53"/>
        <source>Raideur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.cpp" line="58"/>
        <source>Répartition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.cpp" line="63"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="94"/>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="101"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="108"/>
        <source>Modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="115"/>
        <source>Paramètre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="147"/>
        <source>Manuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="152"/>
        <source>Linéaire ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="157"/>
        <source>Linéaire descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="162"/>
        <source>Exponentiel ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="167"/>
        <source>Exponentiel descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="172"/>
        <source>Aléatoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="223"/>
        <source>Ajout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="228"/>
        <source>Multiplication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="233"/>
        <source>Remplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="242"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="247"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="252"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="257"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="262"/>
        <source>Filtre, fréquence (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="267"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="272"/>
        <source>Vol env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="277"/>
        <source>Vol env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="282"/>
        <source>Vol env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="287"/>
        <source>Vol env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="292"/>
        <source>Vol env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="297"/>
        <source>Vol env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="302"/>
        <source>Vol env note → hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="307"/>
        <source>Vol env note → decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="312"/>
        <source>Mod env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="317"/>
        <source>Mod env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="322"/>
        <source>Mod env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="327"/>
        <source>Mod env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="332"/>
        <source>Mod env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="337"/>
        <source>Mod env release (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="342"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="347"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="352"/>
        <source>Mod env note → hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="357"/>
        <source>Mod env note → decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="362"/>
        <source>Mod LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="367"/>
        <source>Mod LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="372"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="377"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="382"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="387"/>
        <source>Vib LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="392"/>
        <source>Vib LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="397"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_paramglobal.ui" line="402"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="407"/>
        <source>Réverbératon (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.ui" line="422"/>
        <source>Appliquer à d&apos;autres instruments...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_paramglobal.cpp" line="38"/>
        <source>Appliquer à d&apos;autres presets...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogRelease</name>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="26"/>
        <source>Élaboration release</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="97"/>
        <source>Désaccordage provoqué (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="104"/>
        <source>Durée release au do 36</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_release.ui" line="111"/>
        <source>Division à l&apos;octave suivante</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSelectItems</name>
    <message>
        <location filename="tools/dialog_selectitems.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_selectitems.ui" line="29"/>
        <source>Tout sélectionner</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_selectitems.ui" line="36"/>
        <source>Sélectionner
instrument courant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSifflements</name>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="17"/>
        <source>Diminuer sifflements</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="tools/dialog_sifflements.ui" line="31"/>
        <source>Début de la coupure (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="38"/>
        <source>Fin de la coupure (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_sifflements.ui" line="45"/>
        <source>Raideur (0-10)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSpace</name>
    <message>
        <location filename="tools/dialog_space.ui" line="26"/>
        <source>Spatialisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="87"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Motif&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="94"/>
        <source>Nombre divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="101"/>
        <source>Etalement (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="108"/>
        <source>Occupation (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="115"/>
        <source>Offset (0-100)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="122"/>
        <source>Renversements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="151"/>
        <source>Ascendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="156"/>
        <source>Creux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="161"/>
        <source>Descendant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tools/dialog_space.ui" line="166"/>
        <source>Pointe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogWait</name>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="20"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gui_divers/dialog_wait.ui" line="27"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphiqueFourier</name>
    <message>
        <location filename="pages/page_smpl.cpp" line="1743"/>
        <source>note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1744"/>
        <source>correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1744"/>
        <source>estimation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="17"/>
        <source>Polyphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="90"/>
        <location filename="mainwindow.ui" line="117"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="191"/>
        <source>&amp;Fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="213"/>
        <source>&amp;Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="221"/>
        <source>&amp;Édition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="236"/>
        <source>&amp;Outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="243"/>
        <source>&amp;Sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="259"/>
        <source>&amp;Sf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="270"/>
        <source>&amp;Instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="285"/>
        <source>&amp;Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="297"/>
        <source>A&amp;ffichage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>Clavier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="320"/>
        <source>Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="383"/>
        <source>Arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>Enroule l&apos;arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="504"/>
        <source>Déroule l&apos;arborescence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="533"/>
        <source>Rechercher...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="546"/>
        <source>Efface la recherche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="573"/>
        <source>&amp;Ouvrir...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="576"/>
        <source>Ouvre un fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="579"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="588"/>
        <source>&amp;Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="591"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="600"/>
        <source>&amp;Manuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="603"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="612"/>
        <source>&amp;A propos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="624"/>
        <location filename="mainwindow.cpp" line="179"/>
        <location filename="mainwindow.cpp" line="290"/>
        <source>&amp;Enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="627"/>
        <source>Enregistre le fichier actuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="630"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="642"/>
        <source>Enregistrer &amp;sous...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="645"/>
        <source>Enregistre sous un autre fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="648"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="657"/>
        <source>&amp;Nouveau...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="660"/>
        <source>Crée un nouveau fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="663"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="675"/>
        <source>&amp;Annuler</source>
        <comment>1</comment>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="678"/>
        <source>Annule la dernière action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="681"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="693"/>
        <source>Ré&amp;tablir</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="696"/>
        <source>Refait la dernière action annulée</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="699"/>
        <source>Ctrl+Shift+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="708"/>
        <source>&amp;Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="719"/>
        <source>&amp;Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="731"/>
        <source>&amp;Fermer le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="734"/>
        <source>Ferme le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="737"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="749"/>
        <source>&amp;Copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="752"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="767"/>
        <source>C&amp;oller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="770"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="785"/>
        <source>&amp;Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="788"/>
        <source>Supprime un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="791"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="802"/>
        <source>&amp;Enlever les éléments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="805"/>
        <source>Enleve les éléments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="813"/>
        <location filename="mainwindow.cpp" line="658"/>
        <location filename="mainwindow.cpp" line="670"/>
        <source>&amp;Renommer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="816"/>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="824"/>
        <source>fichier 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="827"/>
        <location filename="mainwindow.ui" line="841"/>
        <location filename="mainwindow.ui" line="855"/>
        <location filename="mainwindow.ui" line="869"/>
        <location filename="mainwindow.ui" line="883"/>
        <source>Ouvre un fichier récent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="838"/>
        <source>fichier 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="852"/>
        <source>fichier 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="866"/>
        <source>fichier 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="880"/>
        <source>fichier 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="897"/>
        <source>&amp;Section modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="900"/>
        <source>Affiche la section modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="912"/>
        <source>&amp;Importer ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="915"/>
        <source>Importe un fichier audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="923"/>
        <source>E&amp;xporter ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="926"/>
        <source>Exporte au format wav</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="938"/>
        <source>Nouvel instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="941"/>
        <source>Crée un nouvel instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="953"/>
        <source>Nouveau preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="956"/>
        <source>Crée un nouveau preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="961"/>
        <source>&amp;Enlever blanc au départ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="969"/>
        <source>&amp;Ajuster à la fin de boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="974"/>
        <source>&amp;Normaliser volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="979"/>
        <source>&amp;Bouclage automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="984"/>
        <source>&amp;Filtre &quot;mur de brique&quot;...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="989"/>
        <source>&amp;Transposer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="994"/>
        <source>&amp;Régler atténuation minimale...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1002"/>
        <source>&amp;Désaccordage ondulant...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1007"/>
        <source>&amp;Spatialisation du son...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1012"/>
        <source>&amp;Répartition automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1017"/>
        <source>D&amp;uplication des divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1022"/>
        <location filename="mainwindow.ui" line="1116"/>
        <source>&amp;Paramétrage global...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1027"/>
        <source>&amp;Réglage balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1032"/>
        <source>&amp;Création mixture...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1040"/>
        <location filename="mainwindow.ui" line="1045"/>
        <source>&amp;Diminuer sifflements...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1056"/>
        <source>&amp;Clavier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1067"/>
        <source>&amp;5 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1075"/>
        <source>&amp;6 octaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1083"/>
        <source>&amp;128 notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1091"/>
        <source>&amp;Aucun</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1096"/>
        <location filename="mainwindow.ui" line="1101"/>
        <source>&amp;Réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1106"/>
        <source>&amp;Duplication des divisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="1111"/>
        <source>&amp;Élaboration release...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1121"/>
        <source>&amp;Association auto samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="167"/>
        <source>&lt;b&gt;Les fichiers suivants ont Ã©tÃ© modifiÃ©s depuis leur dernier enregistrement :&lt;br/&gt; - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="173"/>
        <location filename="mainwindow.cpp" line="284"/>
        <source>&lt;b&gt;Voulez-vous enregistrer les modifications du fichier Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="173"/>
        <source>&amp;#160;Â» avant de quitter ?&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="176"/>
        <location filename="mainwindow.cpp" line="287"/>
        <source>Si vous n&apos;enregistrez pas, les modifications effectuÃ©es depuis la derniÃ¨re sauvegarde seront dÃ©finitivement perdues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="180"/>
        <location filename="mainwindow.cpp" line="291"/>
        <source>&amp;Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="181"/>
        <source>&amp;Quitter sans enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="211"/>
        <source>Ouvrir une soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="212"/>
        <location filename="mainwindow.cpp" line="373"/>
        <location filename="mainwindow.cpp" line="377"/>
        <source>Fichier .sf2 (*.sf2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="238"/>
        <location filename="mainwindow.cpp" line="241"/>
        <location filename="mainwindow.cpp" line="244"/>
        <location filename="mainwindow.cpp" line="247"/>
        <location filename="mainwindow.cpp" line="250"/>
        <location filename="mainwindow.cpp" line="253"/>
        <location filename="mainwindow.cpp" line="394"/>
        <location filename="mainwindow.cpp" line="397"/>
        <location filename="mainwindow.cpp" line="400"/>
        <location filename="mainwindow.cpp" line="1527"/>
        <location filename="mainwindow.cpp" line="2002"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="241"/>
        <source>Le fichier est dÃ©jÃ  chargÃ©.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="244"/>
        <source>Impossible d&apos;ouvrir le fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="247"/>
        <source>Lecture impossible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="250"/>
        <source>Le fichier est corrompu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="253"/>
        <source>La somme de la taille des blocs ne donne pas la taille totale du fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="260"/>
        <source>Nom de la nouvelle soundfont :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="285"/>
        <source>&amp;#160;Â» avant de le fermer ?&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="292"/>
        <source>&amp;Fermer sans enregistrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="355"/>
        <source>&lt;b&gt;Perte de rÃ©solution </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="355"/>
        <source> bits&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="357"/>
        <source>La qualitÃ© des samples sera abaissÃ©e suite Ã  cette opÃ©ration. Continuer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="360"/>
        <source>&amp;Oui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="361"/>
        <source>&amp;Non</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="373"/>
        <location filename="mainwindow.cpp" line="376"/>
        <source>Sauvegarder une soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="394"/>
        <source>Extension inconnue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="397"/>
        <source>Fichier dÃ©jÃ  ouvert, impossible de sauvegarder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="400"/>
        <source>Impossible d&apos;enregistrer le fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.cpp" line="429"/>
        <source>&lt;b&gt;Polyphone&lt;/b&gt; © 2013&lt;br/&gt;Version : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="430"/>
        <source>&lt;br/&gt;Auteur : Davy Triponney&lt;br/&gt;Site web : &lt;a href=&quot;http://www.polyphone.fr&quot;&gt;www.polyphone.fr&lt;/a&gt;&lt;br/&gt;Support : &lt;a href=&quot;mailto:info@polyphone.fr&quot;&gt;info@polyphone.fr&lt;/a&gt;</source>
        <oldsource>&lt;br/&gt;Auteur : Davy Triponney&lt;br/&gt;Support : &lt;a href=&quot;mailto:info@polyphone.fr&quot;&gt;info@polyphone.fr&lt;/a&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="665"/>
        <source>&amp;Renommer en masse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="827"/>
        <source>Nom des samples (max 15 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="830"/>
        <source>Nom du sample (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="831"/>
        <source>Nom de l&apos;instrument (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="832"/>
        <source>Nom du preset (max 20 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="833"/>
        <source>Nom du SF2 (max 255 caractÃ¨res) :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="836"/>
        <location filename="mainwindow.cpp" line="2324"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1125"/>
        <location filename="mainwindow.cpp" line="1716"/>
        <location filename="mainwindow.cpp" line="1722"/>
        <location filename="mainwindow.cpp" line="1731"/>
        <source>Le sample Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1126"/>
        <location filename="mainwindow.cpp" line="1732"/>
        <source>&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1131"/>
        <location filename="mainwindow.cpp" line="1244"/>
        <location filename="mainwindow.cpp" line="1464"/>
        <location filename="mainwindow.cpp" line="1746"/>
        <source>&amp;Remplacer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1132"/>
        <location filename="mainwindow.cpp" line="1245"/>
        <location filename="mainwindow.cpp" line="1465"/>
        <location filename="mainwindow.cpp" line="1747"/>
        <source>R&amp;emplacer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1133"/>
        <location filename="mainwindow.cpp" line="1246"/>
        <location filename="mainwindow.cpp" line="1466"/>
        <location filename="mainwindow.cpp" line="1748"/>
        <source>&amp;Dupliquer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1134"/>
        <location filename="mainwindow.cpp" line="1247"/>
        <location filename="mainwindow.cpp" line="1467"/>
        <location filename="mainwindow.cpp" line="1749"/>
        <source>D&amp;upliquer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1135"/>
        <location filename="mainwindow.cpp" line="1248"/>
        <location filename="mainwindow.cpp" line="1468"/>
        <location filename="mainwindow.cpp" line="1750"/>
        <source>&amp;Ignorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1136"/>
        <location filename="mainwindow.cpp" line="1249"/>
        <location filename="mainwindow.cpp" line="1469"/>
        <location filename="mainwindow.cpp" line="1751"/>
        <source>I&amp;gnorer tout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1238"/>
        <source>L&apos;instrument Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1239"/>
        <location filename="mainwindow.cpp" line="1459"/>
        <source>&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Souhaitez-vous le remplacer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1458"/>
        <source>Le preset Â«&amp;#160;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1527"/>
        <location filename="mainwindow.cpp" line="2002"/>
        <source>Aucun preset n&apos;est disponible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1681"/>
        <source>Importer un fichier audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1682"/>
        <source>Fichier .wav (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1717"/>
        <source>L&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1723"/>
        <source>R&amp;#160;Â» existe dÃ©jÃ .&lt;br /&gt;Que faire ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1863"/>
        <source>Choisir un rÃ©pertoire de destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1976"/>
        <source>Nom du nouvel instrument :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2012"/>
        <source>Nom du nouveau preset :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2309"/>
        <source>%d sample et </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2310"/>
        <source>%d samples et </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2312"/>
        <source>%d instrument ont Ã©tÃ© supprimÃ©s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2313"/>
        <source>%d instruments ont Ã©tÃ© supprimÃ©s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2325"/>
        <source>AttÃ©nuation minimale (dB) :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page</name>
    <message>
        <location filename="pages/page.cpp" line="102"/>
        <source>, valeur absolue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageTable</name>
    <message>
        <location filename="pages/page.cpp" line="477"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="743"/>
        <location filename="pages/page.cpp" line="765"/>
        <location filename="pages/page.cpp" line="1725"/>
        <location filename="pages/page.cpp" line="1794"/>
        <source>Modulateur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="747"/>
        <source>Lien (invalide)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="1939"/>
        <source>Action impossible : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="1949"/>
        <location filename="pages/page.cpp" line="1958"/>
        <location filename="pages/page.cpp" line="2425"/>
        <location filename="pages/page.cpp" line="2427"/>
        <location filename="pages/page.cpp" line="2433"/>
        <location filename="pages/page.cpp" line="2435"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="1950"/>
        <source>les offsets ne peuvent être modulés dans un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="1959"/>
        <source>&quot; ne peut être modulé dans un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2425"/>
        <source>L&apos;instrument doit contenir des sons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page.cpp" line="2427"/>
        <source>Le preset doit contenir des instruments.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2433"/>
        <source>Aucune étendue de notes spécifiée pour l&apos;instrument.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page.cpp" line="2435"/>
        <source>Aucune étendue de notes spécifiée pour le preset.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Inst</name>
    <message>
        <location filename="pages/page_inst.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="80"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="141"/>
        <location filename="pages/page_inst.ui" line="624"/>
        <source>typeElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="146"/>
        <location filename="pages/page_inst.ui" line="629"/>
        <source>indexSf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="151"/>
        <location filename="pages/page_inst.ui" line="634"/>
        <source>indexElt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="156"/>
        <location filename="pages/page_inst.ui" line="639"/>
        <source>indexElt2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="161"/>
        <source>Etendue note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="166"/>
        <source>Etendue vélocité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="171"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="176"/>
        <source>Balance [-50;50]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="181"/>
        <source>Lecture en boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="186"/>
        <source>Note de base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="191"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="196"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="201"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="206"/>
        <source>Filtre, fréquence (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="217"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="222"/>
        <source>Vol env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="227"/>
        <source>Vol env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="232"/>
        <source>Vol env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="237"/>
        <source>Vol env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="242"/>
        <source>Vol env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="247"/>
        <source>Vol env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="252"/>
        <source>Note → Vol env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="257"/>
        <source>Note → Vol env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="262"/>
        <source>Mod env delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="267"/>
        <source>Mod env attack (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="272"/>
        <source>Mod env hold (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="277"/>
        <source>Mod env decay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="282"/>
        <source>Mod env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="287"/>
        <source>Mod env release (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="292"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="297"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="302"/>
        <source>Note → Mod env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="307"/>
        <source>Note → Mod env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="312"/>
        <source>Mod LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="317"/>
        <source>Mod LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="322"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="327"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="332"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="337"/>
        <source>Vib LFO delay (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="342"/>
        <source>Vib LFO freq (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="347"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="352"/>
        <source>Classe exclusive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="357"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="362"/>
        <source>Réverbération (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="367"/>
        <source>Note fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="372"/>
        <source>Vélocité fixe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="377"/>
        <source>Offset début sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="382"/>
        <source>Offset fin sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="387"/>
        <source>Offset début boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="392"/>
        <source>Offset fin boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="397"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="462"/>
        <source>Modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="525"/>
        <source>copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="538"/>
        <source>coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="644"/>
        <source>indexMod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="649"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="660"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="671"/>
        <source>Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="682"/>
        <location filename="pages/page_inst.ui" line="882"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.ui" line="714"/>
        <source>Source / Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.ui" line="924"/>
        <source>Valeur abs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="117"/>
        <source>&lt;b&gt;Instrument liÃ© Ã  aucun preset.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="119"/>
        <source>&lt;b&gt;Instrument liÃ© au preset : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="121"/>
        <source>&lt;b&gt;Instrument liÃ© aux presets : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="132"/>
        <location filename="pages/page_inst.cpp" line="220"/>
        <location filename="pages/page_inst.cpp" line="295"/>
        <location filename="pages/page_inst.cpp" line="378"/>
        <location filename="pages/page_inst.cpp" line="542"/>
        <location filename="pages/page_inst.cpp" line="755"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="132"/>
        <location filename="pages/page_inst.cpp" line="220"/>
        <location filename="pages/page_inst.cpp" line="295"/>
        <location filename="pages/page_inst.cpp" line="378"/>
        <location filename="pages/page_inst.cpp" line="542"/>
        <location filename="pages/page_inst.cpp" line="755"/>
        <source>L&apos;instrument doit contenir des sons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="138"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="139"/>
        <source>Nombre de battements par seconde :
(le signe dÃ©finit le sens du dÃ©saccordage)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_inst.cpp" line="563"/>
        <source>Création </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="564"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_inst.cpp" line="579"/>
        <source>sans nom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Prst</name>
    <message>
        <location filename="pages/page_prst.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="64"/>
        <source>Banque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="114"/>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="203"/>
        <location filename="pages/page_prst.ui" line="641"/>
        <source>typeElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="208"/>
        <location filename="pages/page_prst.ui" line="646"/>
        <source>indexSf2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="213"/>
        <location filename="pages/page_prst.ui" line="651"/>
        <source>indexElt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="218"/>
        <location filename="pages/page_prst.ui" line="656"/>
        <source>indexElt2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="223"/>
        <source>Etendue note</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="228"/>
        <source>Etendue vélocité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="233"/>
        <source>Atténuation (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="238"/>
        <source>Balance [-50;50]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="243"/>
        <source>Accordage (demi-tons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="248"/>
        <source>Accordage (centièmes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="253"/>
        <source>Accordage (scale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="258"/>
        <source>Filtre, fréquence (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="269"/>
        <source>Filtre, résonance (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="274"/>
        <source>Vol env delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="279"/>
        <source>Vol env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="284"/>
        <source>Vol env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="289"/>
        <source>Vol env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="294"/>
        <source>Vol env sustain (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="299"/>
        <source>Vol env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="304"/>
        <source>Note → Vol env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="309"/>
        <source>Note → Vol env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="314"/>
        <source>Mod env delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="319"/>
        <source>Mod env attack (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="324"/>
        <source>Mod env hold (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="329"/>
        <source>Mod env decay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="334"/>
        <source>Mod env sustain (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="339"/>
        <source>Mod env release (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="344"/>
        <source>Mod env → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="349"/>
        <source>Mod env → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="354"/>
        <source>Note → Mod env hold (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="359"/>
        <source>Note → Mod env decay (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="364"/>
        <source>Mod LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="369"/>
        <source>Mod LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="374"/>
        <source>Mod LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="379"/>
        <source>Mod LFO → filtre (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="384"/>
        <source>Mod LFO → volume (dB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="389"/>
        <source>Vib LFO delay (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="394"/>
        <source>Vib LFO freq (×)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="399"/>
        <source>Vib LFO → ton (c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="404"/>
        <source>Chorus (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="409"/>
        <source>Réverbération (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="414"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="479"/>
        <source>Modulateurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="542"/>
        <source>copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="555"/>
        <source>coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="661"/>
        <source>indexMod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="666"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="677"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="688"/>
        <source>Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="699"/>
        <location filename="pages/page_prst.ui" line="899"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_prst.ui" line="731"/>
        <source>Source / Quantité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.ui" line="941"/>
        <source>Valeur abs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.cpp" line="384"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_prst.cpp" line="384"/>
        <source>Le preset doit contenir des instruments.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Sf2</name>
    <message>
        <location filename="pages/page_sf2.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="42"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="49"/>
        <source>Auteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="56"/>
        <source>Copyright</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="63"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="94"/>
        <source>Date courante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="101"/>
        <source>Produit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="117"/>
        <source>Samples 24 bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="124"/>
        <source>Commentaires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="144"/>
        <source>Nom du fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="151"/>
        <source>Version Soundfont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="158"/>
        <source>Sound engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="165"/>
        <source>Nom et version ROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="172"/>
        <source>Logiciel(s) d&apos;édition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="186"/>
        <location filename="pages/page_sf2.ui" line="199"/>
        <location filename="pages/page_sf2.ui" line="206"/>
        <location filename="pages/page_sf2.ui" line="213"/>
        <location filename="pages/page_sf2.ui" line="220"/>
        <location filename="pages/page_sf2.ui" line="298"/>
        <location filename="pages/page_sf2.ui" line="305"/>
        <location filename="pages/page_sf2.ui" line="312"/>
        <location filename="pages/page_sf2.ui" line="319"/>
        <location filename="pages/page_sf2.ui" line="326"/>
        <location filename="pages/page_sf2.ui" line="333"/>
        <location filename="pages/page_sf2.ui" line="340"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="245"/>
        <source>Nombre de samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="252"/>
        <source>Nombre de samples non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="259"/>
        <source>Nombre d&apos;instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="266"/>
        <source>Nombre d&apos;instruments non utilisés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.ui" line="273"/>
        <source>Nombre de presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="280"/>
        <source>Nombre de paramètres renseignés pour instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_sf2.ui" line="287"/>
        <source>Nombre de paramètres renseignés pour presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="193"/>
        <source>janvier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="194"/>
        <source>fÃ©vrier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="195"/>
        <source>mars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="196"/>
        <source>avril</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="197"/>
        <source>mai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="198"/>
        <source>juin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="199"/>
        <source>juillet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="200"/>
        <source>aoÃ»t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="201"/>
        <source>septembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="202"/>
        <source>octobre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="203"/>
        <source>novembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_sf2.cpp" line="204"/>
        <source>dÃ©cembre</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page_Smpl</name>
    <message>
        <location filename="pages/page_smpl.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="77"/>
        <location filename="pages/page_smpl.ui" line="966"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="158"/>
        <source>&lt;b&gt;Fréquences&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Informations&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="190"/>
        <source>&lt;b&gt;Egaliseur&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="242"/>
        <source>32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="281"/>
        <source>64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="323"/>
        <source>125</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="362"/>
        <source>250</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="401"/>
        <source>500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="440"/>
        <source>1k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="479"/>
        <source>2k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="518"/>
        <source>4k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="557"/>
        <source>8k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="596"/>
        <source>16k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="651"/>
        <source> +15dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="674"/>
        <source>Réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="687"/>
        <source>Appliquer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="707"/>
        <source> -15dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="790"/>
        <source>Lecture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="822"/>
        <source>en boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="857"/>
        <source>stéréo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="864"/>
        <source>sinus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="898"/>
        <source>Taille</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="905"/>
        <source>Boucle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="912"/>
        <source>Note de base</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="pages/page_smpl.ui" line="919"/>
        <source>Correction (centième)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="926"/>
        <source>Echantillonnage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="933"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="940"/>
        <source>Lien</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1063"/>
        <source>192000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1068"/>
        <source>96000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1073"/>
        <source>48000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1078"/>
        <source>44100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1083"/>
        <source>32000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1088"/>
        <source>22050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.ui" line="1093"/>
        <source>11025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="117"/>
        <location filename="pages/page_smpl.cpp" line="356"/>
        <location filename="pages/page_smpl.cpp" line="486"/>
        <location filename="pages/page_smpl.cpp" line="502"/>
        <source>mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="127"/>
        <location filename="pages/page_smpl.cpp" line="487"/>
        <source>droit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="128"/>
        <location filename="pages/page_smpl.cpp" line="488"/>
        <source>gauche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="129"/>
        <location filename="pages/page_smpl.cpp" line="489"/>
        <source>lien</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="183"/>
        <source>&lt;b&gt;Sample liÃ© Ã  aucun instrument.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="185"/>
        <source>&lt;b&gt;Sample liÃ© Ã  l&apos;instrument : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="187"/>
        <source>&lt;b&gt;Sample liÃ© aux instruments : &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="584"/>
        <location filename="pages/page_smpl.cpp" line="639"/>
        <location filename="pages/page_smpl.cpp" line="715"/>
        <location filename="pages/page_smpl.cpp" line="785"/>
        <location filename="pages/page_smpl.cpp" line="860"/>
        <location filename="pages/page_smpl.cpp" line="921"/>
        <location filename="pages/page_smpl.cpp" line="1022"/>
        <location filename="pages/page_smpl.cpp" line="1084"/>
        <source>Traitement </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="585"/>
        <location filename="pages/page_smpl.cpp" line="640"/>
        <location filename="pages/page_smpl.cpp" line="716"/>
        <location filename="pages/page_smpl.cpp" line="786"/>
        <location filename="pages/page_smpl.cpp" line="861"/>
        <location filename="pages/page_smpl.cpp" line="922"/>
        <location filename="pages/page_smpl.cpp" line="1023"/>
        <location filename="pages/page_smpl.cpp" line="1085"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="840"/>
        <location filename="pages/page_smpl.cpp" line="1062"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="841"/>
        <source>FrÃ©quence de coupure :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pages/page_smpl.cpp" line="1063"/>
        <source>Ãcart en demi-tons :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PianoScene</name>
    <message>
        <location filename="clavier/pianoscene.cpp" line="266"/>
        <location filename="clavier/pianoscene.cpp" line="269"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="266"/>
        <source>C♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="266"/>
        <location filename="clavier/pianoscene.cpp" line="269"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="266"/>
        <source>D♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="266"/>
        <location filename="clavier/pianoscene.cpp" line="269"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="267"/>
        <location filename="clavier/pianoscene.cpp" line="270"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="267"/>
        <source>F♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="267"/>
        <location filename="clavier/pianoscene.cpp" line="270"/>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="267"/>
        <source>G♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="268"/>
        <location filename="clavier/pianoscene.cpp" line="271"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="268"/>
        <source>A♯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clavier/pianoscene.cpp" line="268"/>
        <location filename="clavier/pianoscene.cpp" line="271"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="269"/>
        <source>D♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="269"/>
        <source>E♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="270"/>
        <source>G♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="270"/>
        <source>A♭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="clavier/pianoscene.cpp" line="271"/>
        <source>B♭</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pile_sf2</name>
    <message>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="746"/>
        <source>sans titre</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="121"/>
        <location filename="sf2_core/pile_sf2.cpp" line="214"/>
        <location filename="sf2_core/pile_sf2.cpp" line="396"/>
        <location filename="sf2_core/pile_sf2.cpp" line="407"/>
        <location filename="sf2_core/pile_sf2.cpp" line="476"/>
        <location filename="sf2_core/pile_sf2.cpp" line="528"/>
        <location filename="sf2_core/pile_sf2.cpp" line="832"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1127"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1220"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1304"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1549"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1554"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1796"/>
        <location filename="sf2_core/pile_sf2.cpp" line="1989"/>
        <location filename="sf2_core/pile_sf2.cpp" line="2047"/>
        <location filename="sf2_core/pile_sf2.cpp" line="2359"/>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="284"/>
        <location filename="sf2_core/sf2_types.cpp" line="37"/>
        <location filename="sf2_core/sound.cpp" line="90"/>
        <location filename="sf2_core/sound.cpp" line="130"/>
        <location filename="sf2_core/sound.cpp" line="191"/>
        <location filename="sf2_core/sound.cpp" line="254"/>
        <location filename="sf2_core/sound.cpp" line="263"/>
        <location filename="sf2_core/sound.cpp" line="325"/>
        <location filename="sf2_core/sound.cpp" line="534"/>
        <location filename="sf2_core/sound.cpp" line="548"/>
        <location filename="sf2_core/sound.cpp" line="555"/>
        <location filename="sf2_core/sound.cpp" line="561"/>
        <location filename="sf2_core/sound.cpp" line="575"/>
        <location filename="sf2_core/sound.cpp" line="583"/>
        <location filename="sf2_core/sound.cpp" line="1075"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="121"/>
        <source>Dans fonction Pile_sf2::isSet, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="214"/>
        <source>Dans fonction Pile_sf2::get, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="396"/>
        <source>Dans fonction Pile_sf2::getSon, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="407"/>
        <source>Dans fonction Pile_sf2::getQstr, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="476"/>
        <source>Dans fonction Pile_sf2::getData, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="528"/>
        <source>Dans fonction Pile_sf2::count, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="832"/>
        <source>Dans fonction Pile_sf2::add, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="877"/>
        <source>Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="885"/>
        <source>Instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="892"/>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1127"/>
        <source>Dans fonction Pile_sf2::remove, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1221"/>
        <source>Impossible de supprimer un sample s&apos;il est utilisÃ© par un instrument.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1305"/>
        <source>Impossible de supprimer un instrument s&apos;il est utilisÃ© par un preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1549"/>
        <source>Set hidden ne passe pas par la fonction set !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1554"/>
        <source>Dans fonction Pile_sf2::set (valeur), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1796"/>
        <source>Dans fonction Pile_sf2::set (QString), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="1989"/>
        <source>Dans fonction Pile_sf2::set (data), ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="2047"/>
        <source>Dans fonction Pile_sf2::reset, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2.cpp" line="2359"/>
        <source>Dans fonction Pile_sf2::display, ID non valide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/pile_sf2_sl.cpp" line="285"/>
        <source>Fichier corrompu : utilisation des samples en qualitÃ© 16 bits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sf2_types.cpp" line="37"/>
        <source>Lecture impossible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="90"/>
        <location filename="sf2_core/sound.cpp" line="130"/>
        <location filename="sf2_core/sound.cpp" line="191"/>
        <location filename="sf2_core/sound.cpp" line="254"/>
        <source>Fichier non pris en charge.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="263"/>
        <source>Erreur dans Sound::getData.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="326"/>
        <source>Dans setData : opÃ©ration non autorisÃ©e.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="535"/>
        <source>Impossible d&apos;ouvrir le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="548"/>
        <location filename="sf2_core/sound.cpp" line="555"/>
        <location filename="sf2_core/sound.cpp" line="561"/>
        <location filename="sf2_core/sound.cpp" line="575"/>
        <source>Le fichier est corrompu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="584"/>
        <source>RÃ©solution insuffisante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/sound.cpp" line="1076"/>
        <source>Mauvais paramÃ¨tres dans bandFilter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tree</name>
    <message>
        <location filename="sf2_core/tree.cpp" line="55"/>
        <source>Nouveau sample...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="58"/>
        <source>Nouvel instrument...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="61"/>
        <source>Nouveau preset...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="69"/>
        <source>Remplacer par...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="sf2_core/tree.cpp" line="66"/>
        <source>Associer à...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="74"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="75"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="80"/>
        <source>Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="86"/>
        <source>Fermer le fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="211"/>
        <location filename="sf2_core/tree.cpp" line="223"/>
        <location filename="sf2_core/tree.cpp" line="237"/>
        <source>&amp;Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="87"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sf2_core/tree.cpp" line="218"/>
        <source>&amp;Renommer en masse...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
