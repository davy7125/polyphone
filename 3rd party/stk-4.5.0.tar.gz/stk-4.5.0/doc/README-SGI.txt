The Synthesis ToolKit in C++ (STK)

By Perry R. Cook and Gary P. Scavone, 1995--2014.

Please read the file README and INSTALL for more general STK information.

Since STK version 4.3, realtime support for IRIX has been discontinued due to an inability to test it.  If you need realtime support on an SGI, go back to version 4.2.1.  Release 4.0 of STK is confirmed to compile (with various warnings) using CC version 7.30.
